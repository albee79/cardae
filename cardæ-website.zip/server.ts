import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

/**
 * Shared Gemini client utility for server-side generation.
 * User-Agent telemetry set to 'aistudio-build' as required.
 */
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route: Generate brief custom decks tailored for brand/sports clubs
  app.post("/api/generate-brief", async (req, res) => {
    try {
      const { name, vertical, description } = req.body;
      if (!name) {
        return res.status(400).json({ error: "Brand or sports club name is required." });
      }

      const systemInstruction = `You are the Lead Editorial Director at CARDÆ. 
We produce bespoke, ultra-premium heritage card decks (each a masterpieces, 'coffee table books in card format') for elite sports clubs, distilleries, legendary brands, and historical institutions.
Your task is to analyze the brand or sports club provided and write a tailored 54-card deck content concept.
The content must feel rich, historic, poetic, and highly researched. Do not write generic or lazy titles. 
Create beautiful, concrete cards:
- If a football club: name actual historical matches, legendary icons, home ground legends, or specify rich imagery for the illustrative hand-paintings.
- If a vineyard/distillery: mention soil elements, specific aging vaults, legendary tasting nights, or cellar masters.
Return a structured JSON output. Let the tone be elegant, confident, and editorial.`;

      const prompt = `Formulate a luxurious, bespoke CARDÆ card-deck structure for:
Name: "${name}"
Type/Vertical: "${vertical}"
Extra details or purpose: "${description || "To celebrate legendary achievements and living heritage."}"

Complete the editorial review and provide:
1. "tagline": A custom cinematic heritage tagline (e.g., "Siena FC: The legends of the clay walls.")
2. "colorTheme": Descriptive color scheme (e.g., "Imperial Sanguine and Tarnished Brass")
3. "colorHex": A beautiful dark aesthetic primary brand hex code (e.g., "#3b1e1e" or "#0f1c1b") matching their brand
4. "categories": genau exactly 4-5 core thematic categories dividing the 54-card deck (e.g., "The Foundations", "The Golden Era", "The Icons", "The Fan Relics").
   Each category must state a "categoryName", "cardCount" (integer, sum must equal 53), and a "cardItems" array consisting of 3 sample highlighted, highly elaborated cards (each card having a "title" and "description" - which explains what the original hand-illustration represents and the story it tells).
5. "gameMechanic": A custom, optional rules card named "rulesTitle" detailing light rules tailored specifically for this brand ("rulesText", e.g., a custom vintage wine tasting comparison rule or high-stakes football nostalgia trivia). This will be the 54th card.
6. "rationale": An elegant, high-impact paragraph written as an editorial memo justifying why this deck is a superior institutional object (the ultimate farewell presentation, VIP gift, or high-value boutique merch item) compared to generic modern memorabilia.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            required: ["tagline", "colorTheme", "colorHex", "categories", "gameMechanic", "rationale"],
            properties: {
              tagline: { type: Type.STRING },
              colorTheme: { type: Type.STRING },
              colorHex: { type: Type.STRING },
              categories: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  required: ["categoryName", "cardCount", "cardItems"],
                  properties: {
                    categoryName: { type: Type.STRING },
                    cardCount: { type: Type.INTEGER },
                    cardItems: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        required: ["title", "description"],
                        properties: {
                          title: { type: Type.STRING },
                          description: { type: Type.STRING }
                        }
                      }
                    }
                  }
                }
              },
              gameMechanic: {
                type: Type.OBJECT,
                required: ["rulesTitle", "rulesText"],
                properties: {
                  rulesTitle: { type: Type.STRING },
                  rulesText: { type: Type.STRING }
                }
              },
              rationale: { type: Type.STRING }
            }
          }
        }
      });

      const dataText = response.text;
      if (!dataText) {
        throw new Error("Empty response from AI");
      }
      
      const payload = JSON.parse(dataText.trim());
      res.json(payload);
    } catch (error: any) {
      console.error("AI Brief Generator Error:", error);
      res.status(500).json({ error: error.message || "An error occurred while generating your CARDÆ brief." });
    }
  });

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ status: "healthy", timestamp: new Date().toISOString() });
  });

  // Serve static UI assets or mount Vite Dev Middleware
  if (process.env.NODE_ENV !== "production") {
    // Development Mode
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Production Mode
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`CARDÆ Website Server running on http://localhost:${PORT}`);
  });
}

startServer();
