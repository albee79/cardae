import React, { useState, useEffect } from "react";
import { CustomBriefResponse } from "../types";
import { Sparkles, HelpCircle, Download, FileText, ChevronRight, Layers, Flame, Check, ShieldAlert } from "lucide-react";

export default function AIStoryBrief() {
  const [brandName, setBrandName] = useState<string>("");
  const [vertical, setVertical] = useState<string>("Sports Club");
  const [description, setDescription] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessageIndex, setLoadingMessageIndex] = useState<number>(0);
  const [generatedBrief, setGeneratedBrief] = useState<CustomBriefResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  const verticalsList = [
    "Sports Club",
    "Distillery & Wine Estate",
    "Lifestyle & Fashion Brand",
    "Music Artist & Label",
    "Cultural Institution",
    "Historical Family Heritage"
  ];

  const loadingMessages = [
    "Consulting historical archives...",
    "Drafting customizable taglines...",
    "Detailing 54-card editorial structure...",
    "Formulating illustrated card mockups...",
    "Fine-tuning custom rules card mechanics...",
    "Generating editorial memo rationale..."
  ];

  // Rotate loading messages while fetching
  useEffect(() => {
    let interval: any;
    if (isLoading) {
      interval = setInterval(() => {
        setLoadingMessageIndex((prev) => (prev + 1) % loadingMessages.length);
      }, 2500);
    } else {
      setLoadingMessageIndex(0);
    }
    return () => clearInterval(interval);
  }, [isLoading]);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!brandName.trim()) return;

    setIsLoading(true);
    setGeneratedBrief(null);
    setError(null);

    try {
      const response = await fetch("/api/generate-brief", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: brandName,
          vertical,
          description: description
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to communicate with CARDÆ Editorial Team.");
      }

      const data: CustomBriefResponse = await response.json();
      setGeneratedBrief(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "An unexpected error occurred while compiling your card-story proposal.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto rounded-3xl bg-stone-900 border border-stone-800 p-6 md:p-12 shadow-2xl relative overflow-hidden" id="concept-creator">
      <div className="absolute top-0 right-0 w-80 h-80 bg-amber-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
        
        {/* Left half: Input brief formulation */}
        <div className="lg:col-span-4 flex flex-col justify-between space-y-6">
          <div className="space-y-3">
            <span className="text-amber-500 font-mono tracking-widest text-xs uppercase flex items-center gap-1.5 font-semibold">
              <Sparkles className="w-3.5 h-3.5" /> CARDÆ AI Brief Engine
            </span>
            <h3 className="text-2xl font-serif text-stone-100 font-medium tracking-tight">
              Start Your Editorial Outline
            </h3>
            <p className="text-stone-400 text-xs leading-relaxed">
              Input your team or brand characteristics. Our algorithm generates a bespoke, fully customized heritage proposal based on premium CARDAE parameters.
            </p>
          </div>

          <form onSubmit={handleGenerate} className="space-y-4">
            <div>
              <label className="block text-[10px] font-mono uppercase tracking-wider text-stone-400 mb-1.5">
                Brand or Club Name
              </label>
              <input
                type="text"
                required
                disabled={isLoading}
                placeholder="e.g. ACF Fiorentina, Balvenie Castle"
                value={brandName}
                onChange={(e) => setBrandName(e.target.value)}
                className="w-full bg-stone-950 border border-stone-750 rounded-xl px-3.5 py-2.5 text-sm font-sans text-stone-100 placeholder-stone-600 focus:outline-none focus:border-amber-600 focus:ring-1 focus:ring-amber-500/20"
              />
            </div>

            <div>
              <label className="block text-[10px] font-mono uppercase tracking-wider text-stone-400 mb-1.5">
                Vertical Segment
              </label>
              <select
                disabled={isLoading}
                value={vertical}
                onChange={(e) => setVertical(e.target.value)}
                className="w-full bg-stone-950 border border-stone-750 rounded-xl px-3.5 py-2.5 text-sm font-sans text-stone-300 focus:outline-none focus:border-amber-600 focus:ring-1 focus:ring-amber-500/20"
              >
                {verticalsList.map((vert) => (
                  <option key={vert} value={vert}>
                    {vert}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-mono uppercase tracking-wider text-stone-400 mb-1.5 flex justify-between">
                <span>Key Historic Pillars</span>
                <span className="text-stone-600 text-[9px] lowercase">optional</span>
              </label>
              <textarea
                disabled={isLoading}
                rows={3}
                placeholder="List founding dates, legendary icons, specific colors, core mottos, or unique events."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full bg-stone-950 border border-stone-750 rounded-xl p-3.5 text-sm font-sans text-stone-100 placeholder-stone-600 focus:outline-none focus:border-amber-600 focus:ring-1 focus:ring-amber-500/20 resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading || !brandName.trim()}
              className="w-full py-3.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:bg-stone-800 disabled:text-stone-600 text-stone-950 font-sans font-bold text-sm tracking-wide transition-all duration-200 flex items-center justify-center gap-2 shadow-lg"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-stone-950 border-t-transparent rounded-full animate-spin" />
                  <span>Researching...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Formulate Custom Deck</span>
                </>
              )}
            </button>
          </form>

          <p className="text-[10px] text-stone-500 leading-normal bg-stone-950/30 p-3 rounded-lg border border-stone-850">
            *Powered by Gemini 3.5. Outlines are optimized to reflect a real 53-card storytelling distribution plus a 54th rules game mechanic sheet.
          </p>
        </div>

        {/* Right half: Display generated brief deck */}
        <div className="lg:col-span-8 bg-stone-950 border border-stone-800 rounded-2xl p-6 md:p-8 flex flex-col justify-center min-h-[480px] relative">
          
          {/* 1. INITIAL EMPTY STATE */}
          {!isLoading && !generatedBrief && !error && (
            <div className="text-center py-12 max-w-sm mx-auto space-y-4">
              <div className="w-12 h-12 rounded-full bg-stone-900 border border-stone-800 flex items-center justify-center mx-auto">
                <Layers className="w-5 h-5 text-stone-500" />
              </div>
              <div className="space-y-1">
                <h4 className="text-stone-300 font-serif font-semibold text-lg">No Deck Prepared Yet</h4>
                <p className="text-stone-500 text-xs">
                  Fill in your organization name and press "Formulate Custom Deck" to watch our editorial AI research, classify, write, and blueprint your heritage proposal.
                </p>
              </div>
            </div>
          )}

          {/* 2. LOADING STATE WITH ELEGANT TIMER */}
          {isLoading && (
            <div className="text-center py-12 max-w-sm mx-auto space-y-4">
              <div className="w-14 h-14 rounded-full bg-amber-600/10 border border-amber-500/20 flex items-center justify-center mx-auto animate-pulse">
                <Flame className="w-6 h-6 text-amber-500" />
              </div>
              <div className="space-y-2">
                <h4 className="text-stone-250 font-mono text-xs uppercase tracking-wider">
                  Configuring {brandName} Collection
                </h4>
                <div className="text-sm font-serif italic text-amber-400 font-medium h-6">
                  {loadingMessages[loadingMessageIndex]}
                </div>
                <div className="w-48 bg-stone-900 h-1 rounded-full mx-auto overflow-hidden">
                  <div className="h-full bg-amber-500 animate-loading-bar" />
                </div>
              </div>
            </div>
          )}

          {/* 3. EXPLICIT ERROR */}
          {error && (
            <div className="text-center py-12 max-w-md mx-auto space-y-4">
              <div className="w-12 h-12 rounded-full bg-red-950 border border-red-700/30 flex items-center justify-center mx-auto">
                <ShieldAlert className="w-5 h-5 text-red-500" />
              </div>
              <div className="space-y-1">
                <h4 className="text-red-400 font-serif font-semibold text-lg">Editorial Compilation Slipped</h4>
                <p className="text-stone-400 text-xs leading-relaxed">
                  {error}
                </p>
                <div className="pt-3">
                  <button
                    onClick={handleGenerate}
                    className="px-4 py-1.5 rounded-lg bg-stone-900 border border-stone-800 text-stone-300 hover:text-stone-100 text-xs font-mono transition-colors"
                  >
                    Retry Formula
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* 4. SUCCESS BRIEF DETAILS DESIGN */}
          {generatedBrief && (
            <div className="space-y-6 animate-fade-in text-left">
              {/* Cover-styled custom header */}
              <div className="border-b border-stone-800 pb-4">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
                  <div>
                    <span className="font-mono text-[9px] uppercase tracking-widest text-amber-500 font-bold bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded">
                      PROPOSAL DESIGN
                    </span>
                    <h4 className="text-3xl font-serif font-bold text-stone-100 tracking-tight mt-1.5 flex items-center gap-2">
                      {brandName}
                    </h4>
                  </div>
                  <div className="text-sm font-mono text-stone-400 shrink-0 flex items-center gap-2 bg-stone-900 px-3 py-1.5 rounded-lg border border-stone-800/80">
                    <div
                      className="w-4 h-4 rounded-full border border-stone-700 shrink-0"
                      style={{ backgroundColor: generatedBrief.colorHex || "#1c1917" }}
                    />
                    <span>{generatedBrief.colorTheme}</span>
                  </div>
                </div>
                
                <p className="text-sm font-serif italic text-amber-400/90 mt-2 font-medium">
                  "{generatedBrief.tagline}"
                </p>
              </div>

              {/* Categorization & highlights layout */}
              <div className="space-y-4">
                <h5 className="text-[10px] uppercase tracking-widest font-mono text-stone-500 font-semibold">
                  Card Structure Strategy (54 Cards Total)
                </h5>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Category cards loop */}
                  {generatedBrief.categories.map((cat, index) => (
                    <div key={index} className="bg-stone-900/40 p-4 rounded-xl border border-stone-850 space-y-2">
                      <div className="flex justify-between items-baseline">
                        <span className="text-xs font-serif font-bold text-stone-200">
                          {cat.categoryName}
                        </span>
                        <span className="text-[10px] font-mono text-amber-500 bg-amber-500/10 px-1.5 py-0.2 rounded font-semibold whitespace-nowrap">
                          {cat.cardCount} Cards
                        </span>
                      </div>
                      
                      {/* Highlighted Cards prototypes */}
                      <div className="space-y-1.5 pt-1">
                        <span className="text-[9px] font-mono text-stone-500 tracking-wider block uppercase">Highlighted prototypes:</span>
                        {cat.cardItems.slice(0, 3).map((item, id) => (
                          <div key={id} className="text-xs border-l border-amber-500/20 pl-2 leading-relaxed py-0.5">
                            <strong className="text-stone-300 font-serif block">{item.title}</strong>
                            <span className="text-stone-500 text-[10px]">{item.description}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}

                  {/* Rules Card & mechanics */}
                  <div className="bg-stone-900/60 p-4 rounded-xl border border-amber-500/10 space-y-2 col-span-1 md:col-span-2">
                    <div className="flex justify-between items-baseline border-b border-stone-800 pb-1.5">
                      <span className="text-xs font-mono text-amber-500 tracking-wider uppercase font-bold flex items-center gap-1.5">
                        <Flame className="w-3.5 h-3.5 animate-pulse" /> The 54th Card: Optional Mechanics
                      </span>
                      <span className="text-[9px] font-mono text-stone-500 italic">Rules Card inside Box</span>
                    </div>
                    <div>
                      <h6 className="text-sm font-serif text-stone-100 font-bold">{generatedBrief.gameMechanic?.rulesTitle}</h6>
                      <p className="text-xs text-stone-400 font-serif italic mt-0.5 leading-relaxed">
                        {generatedBrief.gameMechanic?.rulesText}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Editorial rationale */}
              <div className="p-4 bg-stone-900/30 border border-stone-800/80 rounded-xl space-y-1.5">
                <span className="font-mono text-[9px] uppercase tracking-wider text-stone-500 block">
                  Editorial Justification Memo
                </span>
                <p className="text-xs text-stone-400 font-sans leading-relaxed text-justify">
                  {generatedBrief.rationale}
                </p>
              </div>

              {/* Direct Booking triggers */}
              <div className="flex flex-col sm:flex-row gap-3 pt-3">
                <a
                  href="#contact"
                  className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 hover:text-stone-100 text-xs font-mono font-semibold rounded-lg border border-stone-700 flex items-center justify-center gap-2 transition-all duration-150"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Lock in this brief structure</span>
                </a>

                <a
                  href={`mailto:alberto.maiorana@gmail.com?subject=CARDÆ Deck Brief Draft for ${brandName}&body=Hi Alberto, I generated a customized proposal outline for our brand, ${brandName}, which we wish to manufacture. Here are the category details: ${generatedBrief.tagline}...`}
                  className="px-4 py-2 bg-amber-500/10 hover:bg-amber-500/20 text-amber-500 text-xs font-mono font-semibold rounded-lg border border-amber-500/20 flex items-center justify-center gap-2 transition-all duration-150 ml-auto"
                >
                  <span>Share Draft Proposal with Team</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
